/* 
 * File:   system_config.h
 * Author: vsk hs-ulm
 *
 * Created on 7. Mai 2014, 09:18
 */
#ifndef SYSTEM_CONFIG_H
#define SYSTEM_CONFIG_H

#include "usb_config.h"

#endif	/* SYSTEM_CONFIG_H */
