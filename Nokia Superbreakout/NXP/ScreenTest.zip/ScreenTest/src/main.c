/*
===============================================================================
 Name        : main.c
 Author      : Peter Barrett
 Version     :
 Copyright   : (C) Copyright Peter Barrett
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC11xx.h"
#endif

#include <stdio.h>

volatile uint32_t _ticks;                            /* counts 1ms timeTicks */
void SysTick_Handler(void)
{
	_ticks++;                        /* increment counter necessary in Delay() */
}

void __aeabi_unwind_cpp_pr0(void)
{
}

void __aeabi_unwind_cpp_pr1(void)
{
}

void NokiaSuperbreakout();

int main(void)
{
	if (SysTick_Config(SystemCoreClock / 1000))
		while (1);
	if (!(SysTick->CTRL & (1<<SysTick_CTRL_CLKSOURCE_Msk)))
		LPC_SYSCON->SYSTICKCLKDIV = 0x08;
	NokiaSuperbreakout();
}
