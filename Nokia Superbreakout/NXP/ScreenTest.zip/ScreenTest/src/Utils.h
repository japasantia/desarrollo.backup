
#ifndef __UTILS__
#define __UTILS__

#include "LPC11xx.h"

extern "C"
{
	#include "string.h"
	int printf ( const char * format, ... );
}

#define PROGMEM
#define pgm_read_byte(_x) (_x)[0]

#ifndef abs
#define abs(_x) ((_x) < 0 ? -(_x) : (_x))
#endif

#ifndef max
#define max(_a,_b) (((_a) > (_b)) ? (_a) : (_b))
#define min(_a,_b) (((_a) < (_b)) ? (_a) : (_b))
#endif

typedef unsigned char u8;
typedef unsigned char byte;
typedef unsigned short u16;
typedef unsigned short ushort;
typedef unsigned long u32;


class Event
{
public:
	enum EType
    {
        None,
		OpenApp,
		CloseApp,

        TouchDown,
        TouchMove,
        TouchUp,

		MicroSDInserted,
		MicroSDRemoved,

		USBAttach,
		USBDetach,
		USBPacket
    };
	EType Type;
	void* Data;
};

#define MAX_APP_BUFFER 1024
typedef int (*AppProc)(Event* e, void* appState);

//	Auto register the app with the Shell, will be called before Shell_Init
class RegisterApp
{
public:
	RegisterApp(const char* name, AppProc proc, int stateSize);
};

void Shell_Init();
void Shell_Loop();
bool Shell_GetAppName(int index, char* name, int len);
void Shell_LaunchApp(const char* params);
void Shell_LaunchFile(const char* filename);
void Shell_InstallApp(const char* name, AppProc proc, int stateSize);
int Shell_AppCount();


#if 0
//	Low Level LCD routines
typedef void (*SetBoundsProc)(int x, int y, int width, int height);
typedef void (*SolidFillProc)(u16 p, u32 count);
typedef void (*PixelFillProc)(u16* p, u32 count);
typedef void (*PixelFillIndexedProc)(u8* p, u16* palette, u32 count);

typedef struct
{
	int	Width;
	int Height;
	SetBoundsProc			SetBounds;
	SolidFillProc			SolidFill;
	PixelFillProc			PixelFill;
	PixelFillIndexedProc	PixelFillIndexed;
} LCD_Info;
#endif

void delay(int ms);

//========================================================================================
//========================================================================================
//	Board HW definitions

#define CS_PORT LPC_GPIO3
#define RESET_PORT LPC_GPIO3
#define RS_PORT LPC_GPIO3
#define WR_PORT LPC_GPIO3
#define RD_PORT LPC_GPIO3
#define CD_PORT LPC_GPIO3

#define CS_BIT	0
#define RESET_BIT 1
#define RS_BIT 2
#define WR_BIT 3
#define RD_BIT 4
#define CD_BIT 5

#define CLR(_p,_b) _p->MASKED_ACCESS[1 << _b] = 0
#define SET(_p,_b) _p->MASKED_ACCESS[1 << _b] = -1

#define CS0 CLR(CS_PORT,CS_BIT)
#define CS1 SET(CS_PORT,CS_BIT)
#define RS0 CLR(RS_PORT,RS_BIT)
#define RS1 SET(RS_PORT,RS_BIT)
#define WR0 CLR(WR_PORT,WR_BIT)
#define WR1 SET(WR_PORT,WR_BIT)
#define RD0 CLR(RD_PORT,RD_BIT)
#define RD1 SET(RD_PORT,RD_BIT)
#define CD0 CLR(CD_PORT,CD_BIT)
#define CD1 SET(CD_PORT,CD_BIT)

#define DC0 CLR(LPC_GPIO2,4)
#define DC1 SET(LPC_GPIO2,4)


#define RESET0 CLR(RESET_PORT,RESET_BIT)
#define RESET1 SET(RESET_PORT,RESET_BIT)

#define DATAOUT {LPC_GPIO2->DIR |= 0xFF; }
#define DATAIN	{LPC_GPIO2->DIR &= ~0xFF; }

#define DATAREAD() 		LPC_GPIO2->DATA
#define DATAWRITE(_data)	LPC_GPIO2->MASKED_ACCESS[0xFF] = _data


//========================================================================================
//========================================================================================
//	SPI Defs for bitbang 3-wire

#define SPI_PORT		LPC_GPIO0
#define SSEL_BIT 		2
#define SPI_RESET_BIT	3
#define SCK_BIT 		6
#define MOSI_BIT 		9

#define SPI_RESET0 CLR(SPI_PORT,SPI_RESET_BIT)
#define SPI_RESET1 SET(SPI_PORT,SPI_RESET_BIT)
#define SSEL0		CLR(SPI_PORT,SSEL_BIT)
#define SSEL1		SET(SPI_PORT,SSEL_BIT)
#define SCK0		CLR(SPI_PORT,SCK_BIT)
#define SCK1		SET(SPI_PORT,SCK_BIT)
#define MOSI0		CLR(SPI_PORT,MOSI_BIT)
#define MOSI1		SET(SPI_PORT,MOSI_BIT)

void	SpiBBWrite(int n, int bits);
int		SpiBBRead(int bits);
void	SpiInit(int bits);	// 8 or 9 bit
void 	SpiClose();
int		SpiWrite(int n);

//========================================================================================
//========================================================================================


//	8 Bit parallel data
void Write8Com(u8 c);
void Write8Data(u8 c);
void Write8DataBegin();
void Write8DataRun(u8 c, int run);
void Write8DataEnd();
u8 Read8();


void InitBoard();
void InitPWM(int dutyCycle, int clockDivisor);

#define DELAY_MS 0x200
#define RESET_MS 0x201


#endif
