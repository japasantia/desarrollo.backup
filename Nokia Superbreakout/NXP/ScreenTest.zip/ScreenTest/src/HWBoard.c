

#include "Utils.h"
#include "HWBoard.h"


extern volatile uint32_t _ticks;
void delay(int ms)
{
	u32 t = ms + _ticks;
	while (_ticks < t)
		;
}


int Read8Com(u8 c)
{
	DATAOUT;
	DATAWRITE(c);
	CS0;
	RS0;
	WR0;
	WR1;
	RS1;
	DATAIN;
	RD0;
	u8 d = DATAREAD();
	RD1;
	CS1;
	return d;
}

void Write8Com(u8 c)
{
	DATAOUT;
	DATAWRITE(0);
	CS0;
	RS0;
	WR0;
	WR1;
	DATAWRITE(c);
	WR0;
	WR1;
	RS1;
	CS1;
}

void Write8Data(u8 c)
{
	DATAOUT;
	DATAWRITE(c);
	CS0;
	WR0;
	WR1;
	CS1;
}

void Write8DataBegin()
{
	DATAOUT;
	CS0;
}

void Write8DataRun(u8 c, int run)
{
	while (run--)
	{
		DATAWRITE(c);
		WR0;
		WR1;
	}
}

void Write8DataEnd()
{
	CS1;
	DATAIN;
}

u8 Read8()
{
	DATAIN;
	CS0;
	RD0;
	u8 d = DATAREAD();
	RD1;
	CS1;
	return d;
}


/* SSP CR1 register */
#define SSPCR1_LBM		(1 << 0)
#define SSPCR1_SSE		(1 << 1)
#define SSPCR1_MS		(1 << 2)
#define SSPCR1_SOD		(1 << 3)

#define SSP_BUFSIZE		16
#define FIFOSIZE		8
#define SSPSR_TNF		(1 << 1)
#define SSPSR_BSY		(1 << 4)

void SpiInit( int bits )
{
  uint8_t i, Dummy;

  LPC_SYSCON->PRESETCTRL |= (0x1<<0);
  LPC_SYSCON->SYSAHBCLKCTRL |= (1<<11);
  LPC_SYSCON->SYSTICKCLKDIV  = 0x02;			/* Divided by 2 */
  LPC_IOCON->PIO0_8 &= ~0x07;	/*  SSP I/O config */
  LPC_IOCON->PIO0_8 |= 0x01;	/* SSP MISO */
  LPC_IOCON->PIO0_9  &= ~0x07;
  LPC_IOCON->PIO0_9 |= 0x01;	/* SSP MOSI */

  LPC_IOCON->SCK_LOC = 0x02;
  LPC_IOCON->PIO0_6 = 0x02;		/* P0.6 function 2 is SSP clock, need to combined with IOCONSCKLOC register setting */


  /* port0, bit 2 is set to GPIO output and high */
  LPC_IOCON->PIO0_2 &= ~0x07;		/* SSP SSEL is a GPIO pin */
  LPC_GPIO0->DIR |= 1 << 2;
  SET(LPC_GPIO0,2);

  LPC_SSP0->CR0 = 0x00C0 + (bits-1);	// n-bit, 24Mhz CPOL = 1, CPHA = 1

  /* SSPCPSR clock prescale register, master mode, minimum divisor is 0x02 */
  LPC_SSP0->CPSR = 0x2;

 // LPC_SSP0->CR0 = (bits-1); 	// CPOL = 0, CPHA = 0
 // LPC_SSP0->CPSR = 0x8;			// 3mhz

  for ( i = 0; i < FIFOSIZE; i++ )
	Dummy = LPC_SSP0->DR;		/* clear the RxFIFO */

  /* Master mode */
  LPC_SSP0->CR1 = SSPCR1_SSE;
}

void SpiClose()
{
	LPC_SSP0->CR1 &= ~SSPCR1_SSE;
	LPC_IOCON->PIO0_8 &= ~0x07;		/*  SSP I/O config */
	LPC_IOCON->PIO0_9  &= ~0x07;
	LPC_IOCON->PIO0_6 = 0x00;		/* P0.6 function 2 is SSP clock, need to combined with IOCONSCKLOC register setting */
}

int SpiWrite(int data)
{
	while (!(LPC_SSP0->SR & SSPSR_TNF))
		;

	LPC_SSP0->DR = data;
	//while ( LPC_SSP0->SR & SSPSR_BSY )
	//	;
	data = LPC_SSP0->DR;
	return data;
}

void SpiBBWrite(int w, int bits)
{
	int i;
	int m = 1 << (bits-1);
	//printf("W 0x%0X ",w);
	for (i = 0; i < bits; i++)
	{
		if (w & m)
		{
			//printf("1");
			MOSI1;
		}
		else
		{
			MOSI0;
			//printf("0");
		}
		SCK0;

		SCK1;
		SCK1;
		SCK1;
		SCK1;

		SCK0;
		SCK0;
		SCK0;
		w <<= 1;
	}
	//printf("\n");
}

int SpiBBRead(int bits)
{
	int n = 0;
	int m = 1 << MOSI_BIT;
	SPI_PORT->DIR &= ~m;
	while (bits--)
	{
		n <<= 1;
		SCK1;
		if (SPI_PORT->DATA & m)
			n |= 1;
		SCK0;
	}

	SPI_PORT->DIR |= m;
	return n;
}


#define F_320 1500
#define F_480 1000
#define F_PWM 500

void InitPWM(int dutyCycle, int clockDivisor)
{
  /* Enable the clock for CT16B1 */
	LPC_SYSCON->SYSAHBCLKCTRL |= (1<<8);
	LPC_IOCON->PIO1_9 = 1;		//	CT16B1_MAT0
	LPC_GPIO1->DIR |= (1<<9);	// out

	LPC_TMR16B1->MR0 = clockDivisor - (clockDivisor*dutyCycle/100);		// 50% Duty cycle at 48hkz
	LPC_TMR16B1->MR3 = clockDivisor;

  /* Configure match control register to reset on MR3 */
	LPC_TMR16B1->MCR = 0x0400;	// reset on MR1

	LPC_TMR16B1->EMR = (3<<4) | 1;

  /* Enable PWM0 and PWM3 */
	LPC_TMR16B1->PWMC = 1 | (1<<3);

  /* Enable Timer1 */
	LPC_TMR16B1->TCR = 1;
}

void InitPWM32(int dutyCycle, int clockDivisor)
{
	LPC_SYSCON->SYSAHBCLKCTRL |= (1<<9);	//  Enable the clock for CT32B
	LPC_IOCON->JTAG_TDI_PIO0_11 = 3;		//	CT32B0_MAT3
	LPC_GPIO0->DIR |= (1<<11);				//  out on CT32B0_MAT3
	LPC_TMR32B0->MR3 = clockDivisor - (clockDivisor*dutyCycle/100);		// 50% Duty cycle at 48hkz
	LPC_TMR32B0->MR0 = clockDivisor;
	LPC_TMR32B0->MCR = 1<<1;				// reset on MR0
	LPC_TMR32B0->PWMC = 1<<3;
	LPC_TMR32B0->TCR = 1;
}

void InitBoard()
{
	//	TFT20
	CS1;
	RS1;
	WR1;
	RD1;
	CD1;
	RESET1;

	LPC_GPIO3->DIR |= 0x3F;		// CS.RS.WR.RD,reset

	LPC_GPIO2->DIR |= 1 << 4;	// DC for oled

	RESET0;
	delay(1);
	RESET1;
	delay(1);


	//	SPI Bitbag
	SPI_PORT->DIR |= (1 << SPI_RESET_BIT) | (1<<SSEL_BIT) | (1<<SCK_BIT)  | (1<<MOSI_BIT);
}
