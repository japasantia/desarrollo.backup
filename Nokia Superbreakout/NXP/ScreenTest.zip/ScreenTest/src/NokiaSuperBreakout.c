

#include "Utils.h"
#include "LCD.h"

u8 buffer[1024];	// Declare it early

int ToPix(int r, int g ,int b)
{
	return (r >> 3) | ((g & 0xFC)<<3) | ((b & 0xf8) << 8);
}


u16 Color16To12(int c)
{
	int r = (c >> 4) & 0xF00;
	int g = (c >> 3) & 0x0F0;
	int b = (c >> 1) & 0x00F;
	return (r | g | b);
}

int D3DProc(Event* e, void* state);
int LatticeProc(Event* e, void* state);

extern volatile uint32_t _ticks;                            /* counts 1ms timeTicks */

void Draw(AppProc app, int count)
{
	Event e;
	e.Type = Event::OpenApp;
	app(&e,buffer);
	e.Type = Event::None;
	u32 end = _ticks + count;
	while (_ticks < end)
	{
		LCDBegin();
		app(&e,buffer);
		LCDEnd();
		if (LCDChanged())
			break;
		if (LCDFormat() == 1)
			delay(25);
	}
}

void TestLCD()
{
	if (LCDFormat() == 1)
	{
		Draw(D3DProc,60000);
	} else {
		Draw(D3DProc,6000);
		Draw(LatticeProc,6000);
	}
}


extern "C"
void NokiaSuperbreakout()
{
	InitBoard();
	for (;;)
	{
		if (LCDInit() == 0)
		{
			while (!LCDChanged())
				TestLCD();
		}
		SpiClose();	// Go back to bb
	}
}
